// init AOS
AOS.init({
  duration: 1200,
});
